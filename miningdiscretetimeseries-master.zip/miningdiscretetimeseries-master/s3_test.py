import os
import pandas as pd
from util import preprocessing, buildingWordEmbedding, seq2seq, misc
from util.constants import *
import json
from pprint import pprint
import matplotlib.pyplot as plt
import heapq
from collections import defaultdict, Counter
import sys


flog = None


def main():
    #### load parameters
    if len(sys.argv) == 1:
        # param_filename = "params_synthetic_data_random.json"
        # param_filename = "params_synthetic_data_simple.json"
        # param_filename = "params_synthetic_data_simple_slen10_wstep1.json"
        # param_filename = "params_synthetic_data_simple_slen20_wstep20.json"
        # param_filename = "params_synthetic_data_simple_char.json"
        param_filename = "params_synthetic_data_complex.json"
    else:
        param_filename = sys.argv[1]

    fp_params = os.path.join(FOLDER_PARAMS, param_filename)
    with open(fp_params) as f:
        params = json.load(f)
    # pprint(params)

    if params["using_synthetic_data"] == 0:
        data_filename = params["data_filename"]
    elif params["using_synthetic_data"] == 1:
        data_filename = param_filename.split(".")[0].replace("params_", "") + ".csv"

    data_filename = os.path.join(FOLDER_DATA, data_filename)
    data_folder = os.path.join(FOLDER_DATA, data_filename.replace(".csv", ""))
    nmt_data_folder = os.path.join(FOLDER_NMT_DATA, data_filename.split("/")[-1].replace(".csv", ""))
    nmt_model_folder = os.path.join(FOLDER_NMT_MODEL, data_filename.split("/")[-1].replace(".csv", ""))
    nmt_infer_folder = os.path.join(FOLDER_NMT_INFER, data_filename.split("/")[-1].replace(".csv", ""))

    #### read csv files, for each sensor's time series
    #### (1) build vocabulary and sentences
    #### (2) build word2vec (optional, as seq2seq can also train embedding from scratch)
    #### (3) split into train/dev/test for later seq2seq model
    # preprocessing_data(params, data_folder, nmt_data_folder, build_word2vec=False)
    # exit()

    # #### test a seq2seq model
    sensor_list = pd.read_csv(os.path.join(nmt_data_folder, kw_sensors), header=None).values.flatten()
    translate_candidates = getTranslateCandidates(sensor_list, nmt_data_folder, nmt_model_folder)
    infer = True   # infer + calculate scores
    # infer = False  # only calculate scores
    testSeq2SeqModel(sensor_list, translate_candidates, nmt_data_folder, nmt_model_folder, nmt_infer_folder, params["seq2seq"], infer=infer)


def testSeq2SeqModel(sensor_list, translate_candidates, nmt_data_folder, nmt_model_folder, nmt_infer_folder, params, infer=True):
    if not infer:
        if not misc.checkExistence(nmt_infer_folder):
            return

    trained_models = []
    for m in os.listdir(nmt_model_folder):
        trained_models.append(m)
    trained_models.sort()

    # test seq2seq model
    if infer:
        for model in trained_models:
            this_infer_folder = os.path.join(nmt_infer_folder, model)
            if not os.path.exists(this_infer_folder):
                os.makedirs(this_infer_folder)
            src, tgt = model.split("#")
            misc.log("***Test Seq2Seq: " + src + "-->" + tgt, None)
            for kw in [kw_normal, kw_abnormal]:
                misc.log("Infer " + kw + " cases...", None, 1)
                for i, fp_input in enumerate(translate_candidates[src][kw]):
                    case = fp_input.split(".")[-1]
                    fp_output = os.path.join(this_infer_folder, kw_infer + "." + case + "." + kw)
                    # inference all "test" samples
                    seq2seq.testForSensorPairs(os.path.join(nmt_model_folder, model), fp_input, fp_output, nmt_data_folder, inference_list=None, verbose=False)
                    # inference denoted "test" samples (by indices) + save their attention images
                    seq2seq.testForSensorPairs(os.path.join(nmt_model_folder, model), fp_input, fp_output, nmt_data_folder,
                        inference_list=[0,1,2], verbose=False)


    # calculate translation scores
    for metric in [kw_bleu, kw_bleu_smooth, kw_accuracy, kw_word_accuracy]:
        flog = open(os.path.join(nmt_infer_folder, "_scores_" + metric + ".txt"), "w")
        for model in trained_models:
            this_infer_folder = os.path.join(nmt_infer_folder, model)
            src, tgt = model.split("#")
            misc.log("***Test Seq2Seq: " + src + "-->" + tgt, flog)
            for kw in [kw_normal, kw_abnormal]:
                misc.log("Infer " + kw + " cases...", flog, 1)
                for i, fp_input in enumerate(translate_candidates[src][kw]):
                    case = fp_input.split(".")[-1]
                    fp_output = os.path.join(this_infer_folder, kw_infer + "." + case + "." + kw)
                    fp_ground_truth = os.path.join(nmt_data_folder, kw_test + "." + tgt)
                    score = seq2seq.evaluateForSensorPairs(fp_ground_truth, fp_output, metric)
                    misc.log(str(i+1) + ". translate " + case + ": " + metric + " score=" + str(score), flog, 2)
        flog.close()


def getTranslateCandidates(sensor_list, nmt_data_folder, nmt_model_folder):
    test_candidates = dict()
    for trained_models in os.listdir(nmt_model_folder):
        src, tgt = trained_models.split("#")
        test_candidates[src] = defaultdict(list)
        test_candidates[src][kw_normal].append(os.path.join(nmt_data_folder, kw_test + "." + src))
        for sensor in sensor_list:
            if sensor != src:
                test_candidates[src][kw_abnormal].append(os.path.join(nmt_data_folder, kw_test + "." + sensor))
    return test_candidates


def preprocessing_data(params, data_folder, nmt_data_folder, build_word2vec=True):
    df = preprocessing.getTimeSeries(params["data_filename"], num_sensors=params["num_sensors"], num_timestamp=params["num_timestamps"],
                                    using_synthetic_data=params["using_synthetic_data"], LKM=params["LKM"])

    #### step1: for every time series, chop it into words with fixed length (i.e., 5 chars -- 5 minutes per word)
    misc.log("***Creating word vocabulary for " + params["data_filename"], flog)
    fp_words = preprocessing.splitCharsIntoWords(df, params["data_preparation"], data_folder)
    misc.log("output_file: " + fp_words, flog, 1)

    sentences_folder = preprocessing.splitWordsIntoSentences(fp_words, params["data_preparation"], data_folder)
    misc.log("sentences_folder: " + sentences_folder, flog, 1)

    #### step2: build word2vec for each word sequence
    #### seq2seq can build word2vec from scrach or used the pretrained word2vec embedding
    if build_word2vec:
        misc.log("***Train Word2Vec for each time series", flog)
        with open(os.path.join("parameters", "word2vec.json")) as f:
            word2vec_params = json.load(f)
        buildingWordEmbedding.buildWord2VecEmbeddingWithGensim(input_folder=data_folder, params=word2vec_params["gensim"], visual=word2vec_params["visualization"])

    #### step3: split dataset into train/dev/test
    preprocessing.split_dataset(data_folder, nmt_data_folder, params["data_preparation"])


if __name__ == "__main__":
    main()
