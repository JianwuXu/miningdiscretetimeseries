import os
import pandas as pd
from util import preprocessing, buildingWordEmbedding, seq2seq, misc
from util.constants import *
import json
from pprint import pprint
import matplotlib.pyplot as plt
import heapq
from collections import defaultdict, Counter
import sys


flog = None


def main():
    #### load parameters
    if len(sys.argv) == 1:
        # param_filename = "params_synthetic_data_random.json"
        # param_filename = "params_synthetic_data_simple.json"
        # param_filename = "params_synthetic_data_simple_slen10_wstep1.json"
        # param_filename = "params_synthetic_data_simple_slen20_wstep20.json"
        # param_filename = "params_synthetic_data_simple_char.json"
        param_filename = "params_synthetic_data_complex.json"
    else:
        param_filename = sys.argv[1]

    fp_params = os.path.join(FOLDER_PARAMS, param_filename)
    with open(fp_params) as f:
        params = json.load(f)
    # pprint(params)

    if params["using_synthetic_data"] == 0:
        data_filename = params["data_filename"]
    elif params["using_synthetic_data"] == 1:
        data_filename = param_filename.split(".")[0].replace("params_", "") + ".csv"

    data_filename = os.path.join(FOLDER_DATA, data_filename)
    data_folder = os.path.join(FOLDER_DATA, data_filename.replace(".csv", ""))
    nmt_data_folder = os.path.join(FOLDER_NMT_DATA, data_filename.split("/")[-1].replace(".csv", ""))
    nmt_model_folder = os.path.join(FOLDER_NMT_MODEL, data_filename.split("/")[-1].replace(".csv", ""))
    
    # #### train a seq2seq model using tensorflow tutorial

    sensor_list = pd.read_csv(os.path.join(nmt_data_folder, kw_sensors), header=None).values.flatten()
    if "simple" in data_filename:
        sensor_pairs = [("CR2_0000", "CR2_0000"), ("CR2_0002", "CR2_0002"), ("CR2_0003", "CR2_0003"),
                        ("CR2_0000", "CR2_0001"), ("CR2_0001", "CR2_0000"),
                        ("CR2_0002", "CR2_0003"), ("CR2_0003", "CR2_0002"),
                        ("CR2_0002", "CR2_0004"), ("CR2_0002", "CR2_0005"),
                        ("CR2_0003", "CR2_0004"), ("CR2_0003", "CR2_0005"),
                        ("CR2_0004", "CR2_0002"), ("CR2_0005", "CR2_0002"),
                        ]
        buildSeq2SeqModelForTargetPairs(sensor_pairs, nmt_data_folder, nmt_model_folder, params["seq2seq"])
    elif "complex" in data_filename:
        sensor_pairs = [
                        ("CR2_0000", "CR2_0001"), ("CR2_0001", "CR2_0000"),
                        ("CR2_0002", "CR2_0003"), ("CR2_0003", "CR2_0002"),
                        ("CR2_0004", "CR2_0005"), ("CR2_0005", "CR2_0004"),
                        ("CR2_0006", "CR2_0007"), ("CR2_0007", "CR2_0006"),
                        ]
        buildSeq2SeqModelForTargetPairs(sensor_pairs, nmt_data_folder, nmt_model_folder, params["seq2seq"])
    else:
        buildSeq2SeqModel(sensor_list, nmt_data_folder, nmt_model_folder, params["seq2seq"])


def buildSeq2SeqModelForTargetPairs(target_sensor_pairs, nmt_data_folder, nmt_model_folder, params):
    # misc.makeDirectories(nmt_model_folder, rmPrev=True)
    misc.makeDirectories(nmt_model_folder, rmPrev=False)
    
    for (source, target) in target_sensor_pairs:
        this_model_folder = os.path.join(nmt_model_folder, source + kw_scat + target)
        if not os.path.exists(this_model_folder):
            misc.log("***Train Seq2Seq: " + source + "-->" + target, flog)
            seq2seq.trainForSensorPairs(source, target, nmt_data_folder, this_model_folder, params)


def buildSeq2SeqModel(sensor_list, nmt_data_folder, nmt_model_folder, params):
    misc.makeDirectories(nmt_model_folder, rmPrev=True)

    num_sensors = len(sensor_list)
    for i in xrange(num_sensors):
        for j in xrange(num_sensors):
            if i == j: continue
            misc.log("***Train Seq2Seq: " + sensor_list[i] + "-->" + sensor_list[j], flog)
            this_model_folder = os.path.join(nmt_model_folder, sensor_list[i] + kw_scat + sensor_list[j])
            seq2seq.trainForSensorPairs(sensor_list[i], sensor_list[j], nmt_data_folder, this_model_folder, params)


if __name__ == "__main__":
    main()
