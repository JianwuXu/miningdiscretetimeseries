import os
import pandas as pd
from util import preprocessing, buildingWordEmbedding, seq2seq, misc
from util.constants import *
import json
from pprint import pprint
import matplotlib.pyplot as plt
import heapq
from collections import defaultdict, Counter


flog = None


def main():
    #### load parameters
    # param_filename = "params_synthetic_data_random.json"
    # param_filename = "params_synthetic_data_simple.json"
    # param_filename = "params_synthetic_data_simple_slen10_wstep1.json"
    # param_filename = "params_synthetic_data_simple_slen20_wstep20.json"
    # param_filename = "params_synthetic_data_simple_char.json"
    param_filename = "params_synthetic_data_complex.json"

    fp_params = os.path.join(FOLDER_PARAMS, param_filename)
    with open(fp_params) as f:
        params = json.load(f)
    # pprint(params)

    if params["using_synthetic_data"] == 0:
        data_filename = params["data_filename"]
    elif params["using_synthetic_data"] == 1:
        data_filename = param_filename.split(".")[0].replace("params_", "") + ".csv"

    data_filename = os.path.join(FOLDER_DATA, data_filename)
    data_folder = os.path.join(FOLDER_DATA, data_filename.replace(".csv", ""))
    nmt_data_folder = os.path.join(FOLDER_NMT_DATA, data_filename.split("/")[-1].replace(".csv", ""))
    nmt_model_folder = os.path.join(FOLDER_NMT_MODEL, data_filename.split("/")[-1].replace(".csv", ""))
    nmt_infer_folder = os.path.join(FOLDER_NMT_INFER, data_filename.split("/")[-1].replace(".csv", ""))

    sensor_list = pd.read_csv(os.path.join(nmt_data_folder, kw_sensors), header=None).values.flatten()
    visualizeSeq2SeqModel(sensor_list, nmt_data_folder, nmt_model_folder)


def visualizeSeq2SeqModel(sensor_list, nmt_data_folder, nmt_model_folder):
    sensor_pairs = defaultdict(list)
    for folder in os.listdir(nmt_model_folder):
        src, tgt = folder.split("#")
        sensor_pairs[src].append(tgt)

    for src in sorted(sensor_pairs):
        for tgt in sorted(sensor_pairs[src]):
            misc.log(src + "-->" + tgt, flog)
            this_model_folder = os.path.join(nmt_model_folder, src + kw_scat + tgt)
            misc.log(seq2seq.generateVisualizationCommand(this_model_folder, port=2222), flog, 1)    
            misc.log(seq2seq.generateVimDiffCommand(kw_dev, src, tgt, nmt_data_folder, nmt_model_folder), flog, 1)
            misc.log(seq2seq.generateVimDiffCommand(kw_test, src, tgt, nmt_data_folder, nmt_model_folder), flog, 1)


def visualizeSeq2SeqModelBySimilarity(sensor_list, nmt_data_folder, nmt_model_folder):
    sensor_to_nearest = defaultdict(list)
    num_sensors = len(sensor_list)
    for i in xrange(num_sensors):
        source = sensor_list[i]
        for j in xrange(num_sensors):
            target = sensor_list[j]
            # print source + kw_scat + target

            # get the count of unique words in the prediction of taret sensor output
            this_model_folder = os.path.join(nmt_model_folder, source + kw_scat + target)
            if not os.path.exists(this_model_folder):
                continue
            fp_dev = os.path.join(this_model_folder, "output_dev")
            fp_test = os.path.join(this_model_folder, "output_test")
            word_counter = Counter()
            for fn in [fp_dev, fp_test]:
                fdata = open(fn)
                for line in fdata:
                    word_counter.update(line.strip().split())
                fdata.close()
            counter_size = len(word_counter)
            heapq.heappush(sensor_to_nearest[source], [-counter_size, target])

    for k in sorted(sensor_to_nearest):
        nearest = sensor_to_nearest[k][0]  # peek the heap
        misc.log(k + "-->" + nearest[1] + ": output_size=" + str(-nearest[0]))
        this_model_folder = os.path.join(nmt_model_folder, k + kw_scat + nearest[1])
        misc.log(seq2seq.generateVisualizationCommand(this_model_folder, port=2222), flog, 1)    
        misc.log(seq2seq.generateVimDiffCommand(kw_dev, k, nearest[1], nmt_data_folder, nmt_model_folder), flog, 1)
        misc.log(seq2seq.generateVimDiffCommand(kw_test, k, nearest[1], nmt_data_folder, nmt_model_folder), flog, 1)


if __name__ == "__main__":
    main()
