rm -r data/synthetic_data_small
rm -r _nmt_data
rm -r _nmt_model

