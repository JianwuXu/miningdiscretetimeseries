git add .
git commit -m "misc"
git push origin master

