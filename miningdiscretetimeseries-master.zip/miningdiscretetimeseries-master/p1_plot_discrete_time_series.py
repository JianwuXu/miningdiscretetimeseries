import os
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from util.constants import *
import json

#####
#####

def main():
    #### load parameters
    # param_filename = "params_synthetic_data_random.json"
    #### filenames with "simple" keyword -- all from same source data
    # param_filename = "params_synthetic_data_simple.json"
    # param_filename = "params_synthetic_data_simple_slen10_wstep1.json"
    # param_filename = "params_synthetic_data_simple_slen20_wstep20.json"
    # param_filename = "params_synthetic_data_simple_char.json"
    param_filename = "params_synthetic_data_complex.json"

    fp_params = os.path.join(FOLDER_PARAMS, param_filename)
    with open(fp_params) as f:
        params = json.load(f)
    # pprint(params)

    if params["using_synthetic_data"] == 0:
        data_filename = params["data_filename"]
    elif params["using_synthetic_data"] == 1:
        data_filename = param_filename.split(".")[0].replace("params_", "") + ".csv"

    data_filename = os.path.join(FOLDER_DATA, data_filename)
    df = pd.read_csv(data_filename)
    df.drop(COL_TS, axis=1, inplace=True)
    df = df.head(30)
    df = df.applymap(convertToInteger)

    target_sensors = [
                    ['CR2_0000', 'CR2_0001'],
                    ['CR2_0003', 'CR2_0002'],
                    ['CR2_0002', 'CR2_0003', 'CR2_0004', 'CR2_0005', 'CR2_0000'],
    ]

    fig_folder = os.path.join(FOLDER_FIGS, "timeseries")
    for targets in target_sensors:
        plot_discrete_time_seres(df, targets, fig_folder)


def plot_discrete_time_seres(df, target_sensors, fig_folder):
    if not os.path.exists(fig_folder):
        os.makedirs(fig_folder)

    fig_name = os.path.join(fig_folder, "#".join(target_sensors) + ".pdf")
    print fig_name
    f, ax_arr = plt.subplots(len(target_sensors), 1, sharex=True, sharey=False, figsize=(5.5, len(target_sensors)))
    for i, col in enumerate(target_sensors):
        ax = ax_arr[i]
        y = df[col].values
        x = range(df[col].shape[0])
        ax.step(x, y, linestyle="solid")
        plt.xlim(-1, len(x))
        ax.set_axisbelow(True)
        ax.yaxis.grid(b=True, which='major', color='0.8', linestyle='-')
        ax.yaxis.grid(b=True, which='minor', color='0.8', linestyle='-')
        ax.xaxis.grid(b=True, which='major', color='1.0', linestyle='-')
        ax.tick_params('both', which="both", direction='in')
    plt.savefig(fig_name, bbox_inches='tight')
    # plt.show()
    plt.close()


def convertToInteger(cell):
    return ord(cell) - ord('a') + 1


if __name__ == "__main__":
    main()