import os
import pandas as pd
from util import preprocessing, buildingWordEmbedding, seq2seq, misc
from util.constants import *
import json
from pprint import pprint
import matplotlib.pyplot as plt
import heapq
from collections import defaultdict, Counter


flog = None


def main():
    #### load parameters
    # param_filename = "params_synthetic_data_random.json"
    # param_filename = "params_synthetic_data_simple.json"
    # param_filename = "params_synthetic_data_simple_slen10_wstep1.json"
    # param_filename = "params_synthetic_data_simple_slen20_wstep20.json"
    # param_filename = "params_synthetic_data_simple_char.json"
    param_filename = "params_synthetic_data_complex.json"

    fp_params = os.path.join(FOLDER_PARAMS, param_filename)
    with open(fp_params) as f:
        params = json.load(f)
    # pprint(params)

    if params["using_synthetic_data"] == 0:
        data_filename = params["data_filename"]
    elif params["using_synthetic_data"] == 1:
        data_filename = param_filename.split(".")[0].replace("params_", "") + ".csv"

    data_filename = os.path.join(FOLDER_DATA, data_filename)
    data_folder = os.path.join(FOLDER_DATA, data_filename.replace(".csv", ""))
    nmt_data_folder = os.path.join(FOLDER_NMT_DATA, data_filename.split("/")[-1].replace(".csv", ""))
    nmt_model_folder = os.path.join(FOLDER_NMT_MODEL, data_filename.split("/")[-1].replace(".csv", ""))
    nmt_infer_folder = os.path.join(FOLDER_NMT_INFER, data_filename.split("/")[-1].replace(".csv", ""))
    fig_folder = os.path.join(FOLDER_FIGS, kw_infer, data_filename.split("/")[-1].replace(".csv", ""))

    # get BLEU score
    eval_score = getScore(nmt_infer_folder, metric=params["seq2seq"]["metrics"])
    
    sensor_list = pd.read_csv(os.path.join(nmt_data_folder, kw_sensors), header=None).values.flatten()
    targets = getTargets(nmt_data_folder)

    truncate = 30
    decodeTranslatedTimeSeries(fig_folder, targets, eval_score, nmt_infer_folder, nmt_data_folder, 
                    params["data_preparation"], metric=params["seq2seq"]["metrics"],
                    truncate=truncate)

    plotInputTimeSeries(data_filename, fig_folder, targets, nmt_data_folder, params["data_preparation"], truncate=truncate)


def getTargets(nmt_data_folder):
    if "simple" in nmt_data_folder:
        targets = {
            "CR2_0003#CR2_0002": {
                kw_normal: ["CR2_0003"],
                kw_abnormal: ["CR2_0004", "CR2_0005", "CR2_0000"],
            },
            "CR2_0000#CR2_0001": {
                kw_normal: ["CR2_0000"],
                kw_abnormal: ["CR2_0001", "CR2_0002", "CR2_0003"],
            },
        }
    elif "complex" in nmt_data_folder:
        targets = {
            "CR2_0000#CR2_0001": {
                kw_normal: ["CR2_0000"],
                kw_abnormal: ["CR2_0002", "CR2_0004"],
            },
            "CR2_0001#CR2_0000": {
                kw_normal: ["CR2_0001"],
                kw_abnormal: ["CR2_0003", "CR2_0005"],
            },
            "CR2_0002#CR2_0003": {
                kw_normal: ["CR2_0002"],
                kw_abnormal: ["CR2_0000", "CR2_0004"],
            },
            "CR2_0003#CR2_0002": {
                kw_normal: ["CR2_0003"],
                kw_abnormal: ["CR2_0001", "CR2_0005"],
            },
            "CR2_0004#CR2_0005": {
                kw_normal: ["CR2_0004"],
                kw_abnormal: ["CR2_0000", "CR2_0002"],
            },
            "CR2_0005#CR2_0004": {
                kw_normal: ["CR2_0005"],
                kw_abnormal: ["CR2_0001", "CR2_0003"],
            },
            "CR2_0006#CR2_0007": {
                kw_normal: ["CR2_0006"],
                kw_abnormal: ["CR2_0000", "CR2_0001", "CR2_0002", "CR2_0003", "CR2_0004", "CR2_0005"],
            },
            "CR2_0007#CR2_0006": {
                kw_normal: ["CR2_0007"],
                kw_abnormal: ["CR2_0000", "CR2_0001", "CR2_0002", "CR2_0003", "CR2_0004", "CR2_0005"],
            },
        }
    return targets


def plotInputTimeSeries(data_filename, fig_folder, targets, nmt_data_folder, params, truncate=float("inf"), fontsize=14):
    for target_model in sorted(targets):
        src, tgt = target_model.split("#")
        misc.log("***Test Seq2Seq: " + src + "-->" + tgt, None)

        fig_name = os.path.join(fig_folder, target_model + "#input.pdf").replace("#", "_")

        case_list, file_list = [], []
        for kw in [kw_normal, kw_abnormal]:
            for case in targets[target_model][kw]:
                case_list.append(kw + "." + case)
                file_list.append(kw_test + "." + case)

        df = pd.DataFrame()
        for i, col in enumerate(case_list):
            fp_groudtruth = os.path.join(nmt_data_folder, file_list[i])
            ts_groundtruth = decodeSentenceFileBackToTimeSeries(fp_groudtruth, params, truncate)
            df[col] = list(ts_groundtruth)
        df = df.applymap(converCharToInt)

        f, ax_arr = plt.subplots(len(case_list), 1, sharex=True, sharey=False, figsize=(4.2, len(case_list)))
        for i, col in enumerate(case_list):
            ax = ax_arr[i]
            y = df[col].values
            x = range(df.shape[0])
            ax.step(x, y, linestyle="solid")
            plt.xlim(-1, len(x))
            ax.set_ylabel(col.replace(".", "\n"), fontsize=fontsize-4)
            ax.set_axisbelow(True)
            ax.yaxis.grid(b=True, which='major', color='0.8', linestyle='-')
            ax.yaxis.grid(b=True, which='minor', color='0.8', linestyle='-')
            ax.xaxis.grid(b=True, which='major', color='1.0', linestyle='-')
            ax.tick_params('both', which="both", direction='in')
        plt.savefig(fig_name, bbox_inches='tight')
        # plt.show()
        plt.close()


def decodeTranslatedTimeSeries(fig_folder, targets, eval_score, nmt_infer_folder, nmt_data_folder, params, metric, truncate=float("inf")):
    for target_model in sorted(targets):
        this_score = eval_score[target_model]

        this_infer_folder = os.path.join(nmt_infer_folder, target_model)
        if not misc.checkExistence(this_infer_folder):
            return

        src, tgt = target_model.split("#")
        misc.log("***Test Seq2Seq: " + src + "-->" + tgt, None)
        
        df = pd.DataFrame()
        column_names = []
        fp_groudtruth = os.path.join(nmt_data_folder, kw_test + "." + tgt)
        ts_groundtruth = decodeSentenceFileBackToTimeSeries(fp_groudtruth, params, truncate)
        df[kw_gt + "." + tgt] = list(ts_groundtruth)
        column_names.append(kw_gt + "." + tgt)
        
        for kw in [kw_normal, kw_abnormal]:
            for case in targets[target_model][kw]:
                print kw, case
                ts = decodeSentenceFileBackToTimeSeries(os.path.join(this_infer_folder, kw_infer + "." + case + "." + kw), params, truncate)
                df[kw + "." + case] = list(ts)
                column_names.append(kw + "." + case)
        df.columns = column_names
        df = df.applymap(converCharToInt)

        if not os.path.exists(fig_folder):
            os.makedirs(fig_folder)
        plot_discrete_time_seres(df, target_model, this_score, metric, fig_folder)


def plot_discrete_time_seres(df, target_model, eval_score, metric, fig_folder, fontsize=14):
    fig_name = os.path.join(fig_folder, target_model + "#infer.pdf").replace("#", "_")
    columns = list(df.columns.values)

    f, ax_arr = plt.subplots(len(columns), 1, sharex=True, sharey=False, figsize=(5.5, len(columns)))
    for i, col in enumerate(columns):
        ax = ax_arr[i]
        if i == 0:
            ax.set_title("Model:" + target_model.replace("#", "-->"), fontsize=fontsize-4)

        y = df[col].values
        x = range(df[col].shape[0])
        if sum(y) > 0:
            ax.step(x, y, linestyle="solid")
            txt_y = 1
        else:
            txt_y = 0            

        if kw_gt not in col:
            txt = metric.upper() + "=\n" + str(round(eval_score[col.split(".")[-1]], 2))
            ax.text(len(x)+1, txt_y, txt, fontsize=fontsize-4)
        
        ax.set_ylabel(col.replace(".", "\n"), fontsize=fontsize-4)
        ax.set_xlim(-1, len(x))
        ax.set_axisbelow(True)
        ax.grid(True)
        # ax.yaxis.grid(b=True, which='major', color='0.8', linestyle='-')
        # ax.yaxis.grid(b=True, which='minor', color='0.8', linestyle='-')
        # ax.xaxis.grid(b=True, which='major', color='1.0', linestyle='-')
        ax.tick_params('both', which="both", direction='in')

    plt.savefig(fig_name, bbox_inches='tight')
    # plt.show()
    plt.close()


def decodeSentenceFileBackToTimeSeries(filename, params, truncate=float("inf"), offset=0):
    wlen, cstep = params["word_length"], params["char_step"]
    slen, wstep = params["sentence_length"], params["word_step"]

    if wstep > slen:
        print "word_step(wstep=" + str(wstep) + ") cannot be greater than sentence_length(slen=" + str(slen) + ")"
        exit()

    word_list = None
    fdata = open(filename)
    lines = fdata.readlines()
    fdata.close()
    for line in lines[offset:offset+truncate+1]:
        words = line.strip().split()
        if word_list is None:
            word_list = words
        else:
            word_list.extend(words[-wstep:])

    if len(word_list) == 0:
        timeseries = "".join([chr(ord('a')-1)] * truncate)
    else:
        timeseries = convertSentenceBackToTimeSeries(word_list, wlen, cstep, truncate)
    return timeseries


def convertSentenceBackToTimeSeries(word_list, wlen, cstep, truncate=float("inf")):
    if cstep > wlen:
        print "char_step(cstep=" + str(cstep) + ") cannot be greater than word_length(wlen=" + str(wlen) + ")"
        exit()

    timeseries = word_list[0]
    ts_len = len(timeseries)
    for w in word_list[1:]:
        timeseries += w[-cstep:]
        ts_len += cstep
        if ts_len > truncate:
            break
    return timeseries[:truncate]


def converCharToInt(cell):
    return ord(cell) - ord('a') + 1


def getScore(nmt_infer_folder, metric=kw_bleu):
    fp = os.path.join(nmt_infer_folder, "_scores_" + metric + ".txt")

    #***Test Seq2Seq: CR2_0003-->CR2_0002
    # Infer normal cases...
    #     1. translate CR2_0003: bleu score=100.0
    # Infer abnormal cases...
    #     1. translate CR2_0000: bleu score=90.5334535593
    #     2. translate CR2_0001: bleu score=90.5334535593
    #     3. translate CR2_0002: bleu score=90.5334535593
    #     4. translate CR2_0004: bleu score=90.998828081
    #     5. translate CR2_0005: bleu score=88.3583645366

    info = dict()
    fdata = open(fp)
    cur_model = ""
    for line in fdata:
        if "-->" in line:
            cur_model = line.strip().split(": ")[-1].replace("-->", "#")
            if cur_model not in info:
                info[cur_model] = dict()
        elif "translate" in line:
            case = line.strip().split()[2][:-1]
            score = float(line.strip().split("=")[-1])
            info[cur_model][case] = score
    return info


if __name__ == "__main__":
    main()
