# generate synthetic data as the real sensor data is confidential
import os
import pandas as pd
import string
import random
from constants import *
import misc

random.seed(RANDOM_SEED)


def split_dataset(data_folder, output_folder, params, flog=None):
    misc.makeDirectories(output_folder, rmPrev=True)

    # create sensor list files
    sensor_list = pd.read_csv(os.path.join(data_folder, kw_sensors), header=None).values.flatten()
    fp_sensors = os.path.join(output_folder, "sensors")
    pd.Series(sensor_list).to_csv(fp_sensors, index=False)

    # create vocabulary files
    misc.log("Create vocabulary files for sensors...", flog)
    if params["sentence_length"] > 1:
        fp_words = os.path.join(data_folder, "words_winSize_" + str(params["word_length"]) + "_step_" + str(params["char_step"]) + ".csv")
        df = pd.read_csv(fp_words)
        # df.drop(COL_TS, axis=1, inplace=True)
        for sensor_id in sensor_list:
            misc.log("<vocab> Sensor: " + sensor_id, flog, 1)
            fp_vocab_out = os.path.join(output_folder, kw_vocab + "." + sensor_id)
            this_vocab = df[sensor_id].unique()
            this_vocab = pd.concat((pd.Series(["<unk>", "<s>", "</s>"]), pd.Series(this_vocab)))
            this_vocab.to_csv(fp_vocab_out, index=False)
    elif params["sentence_length"] == 1:
        fp_timeseries = data_folder + ".csv"
        df = pd.read_csv(fp_timeseries)
        # df.drop(COL_TS, axis=1, inplace=True)
        for sensor_id in sensor_list:
            misc.log("<vocab> Sensor: " + sensor_id, flog, 1)
            fp_vocab_out = os.path.join(output_folder, kw_vocab + "." + sensor_id)
            this_vocab = df[sensor_id].unique()
            this_vocab = pd.concat((pd.Series(["<unk>", "<s>", "</s>"]), pd.Series(this_vocab)))
            this_vocab.to_csv(fp_vocab_out, index=False)

    # split train/dev/test for sentence files
    misc.log("Create sentences files for sensors, split into train/dev/test datasets...", flog)
    sentences_folder = os.path.join(data_folder, FOLDER_SENTENCES)

    # step1: determine dataset sizes
    df = pd.read_csv(os.path.join(sentences_folder, sensor_list[0] + ".csv"), header=None)
    sentence_size = df.shape[0]
    size_train, size_dev = int(round(sentence_size * params["dataset_split"][kw_train])), int(round(sentence_size * params["dataset_split"][kw_dev]))
    size_test = sentence_size - size_train - size_dev
    misc.log("Dataset size: train=" + str(size_train) + ", dev=" + str(size_dev) + ", test=" + str(size_test), flog)

    # step2: slice for each sensor sentences
    for sensor_id in sensor_list:
        misc.log("<sentences> Sensor: " + sensor_id, flog, 1)
        df = pd.read_csv(os.path.join(sentences_folder, sensor_id + ".csv"), header=None)
        index_list = df.index.values

        idx_dict = dict()
        idx_dict[kw_train] = index_list[: size_train]
        idx_dict[kw_dev] = index_list[size_train: size_train + size_dev]
        idx_dict[kw_test] = index_list[size_train + size_dev:]

        for kw in [kw_train, kw_dev, kw_test]:
            fp_sentence_output = os.path.join(output_folder, kw + "." + sensor_id)
            this_df = df.loc[idx_dict[kw]]
            this_df.to_csv(fp_sentence_output, index=False, header=False)
            

def splitWordsIntoSentences(fp_input, params, output_folder):
    if params["sentence_length"] > 1: # word = list of chars, sentences = list of words
        df = pd.read_csv(fp_input)
        df.drop(COL_TS, axis=1, inplace=True)

        df_sentences = df.apply(splitWordsIntoSentencesHelper, axis=0, winSize=params["sentence_length"], step=params["word_step"])
        # print df_sentences.shape   # (num_timestamp_for_sentences, num_sensor), each cell represents a sentence

    elif params["sentence_length"] == 1: # word = one char, sentences = list of chars
        df = pd.read_csv(fp_input)
        df.drop(COL_TS, axis=1, inplace=True)

        df_sentences = df.applymap(getCharSentences)  # apply to every cell
        # print df_sentences.shape   # (num_timestamp_for_sentences, num_sensor), each cell represents a sentence

    output_folder = os.path.join(output_folder, FOLDER_SENTENCES)
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for sensor_id in df_sentences:
        df_sentences[sensor_id].to_csv(os.path.join(output_folder, sensor_id + ".csv"), index=False)
    return output_folder


def getCharSentences(sequence): # word = one char, sentences = list of chars
    return " ".join(list(sequence))


def splitWordsIntoSentencesHelper(sequence, winSize=10, step=1):  # word = list of chars, sentences = list of words
    numOfChunks = ((sequence.shape[0] - winSize) / step) + 1
    # print "numOfChunks=", numOfChunks

    res = []
    for i in range(0, numOfChunks * step, step):
        sentences = " ".join(sequence[i : i + winSize].values)
        res.append(sentences)
    return pd.Series(res)


def splitCharsIntoWords(df, params, output_folder):
    # split chars into words
    df_words = df.apply(splitCharsIntoWordsHelper, axis=0, winSize=params["word_length"], step=params["char_step"])
    df_words.index.name = COL_TS
    # print df_words.shape  # (num_timestamp_for_words, num_sensors), each cell represents a word

    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    fp_output = os.path.join(output_folder, "words_winSize_" + str(params["word_length"]) + "_step_" + str(params["char_step"]) + ".csv")
    df_words.to_csv(fp_output)
    pd.Series(df_words.columns).to_csv(os.path.join(output_folder, "sensors"), index=False)
    return fp_output


def splitCharsIntoWordsHelper(sequence, winSize=10, step=1):
    numOfChunks = ((sequence.shape[0] - winSize) / step) + 1
    # print "numOfChunks=", numOfChunks

    res = []
    for i in range(0, numOfChunks * step, step):
        word = "".join(sequence[i : i + winSize].values)
        res.append(word)
    return pd.Series(res)


def getTimeSeries(filename, num_sensors, num_timestamp, using_synthetic_data=True, LKM=None):
    if using_synthetic_data:
        if not os.path.exists(filename):
            create_synthetic_data(filename, num_sensors, num_timestamp,
                                  card_cnt=LKM["cardinality_count"], sensor_prefix=LKM["sensor_prefix"])
        df = pd.read_csv(filename).astype(str)
        index_name = df.columns.values[0]
        df.drop(index_name, axis=1, inplace=True)
        return df

    else:
        print "Do not have access to real data."
        exit()


def create_synthetic_data(filename, num_sensors, num_timestamp, card_cnt, sensor_prefix=""):
    if "simple" in filename:
        num_timestamp = (num_timestamp / 24) * 24
        ts1 = "".join(["abc"] * (num_timestamp/3))
        ts2 = "".join(["cba"] * (num_timestamp/3))
        ts3 = "".join(["bcbcbaba"] * (num_timestamp/8))
        ts4 = "".join(["aaaabbbb"] * (num_timestamp/8))
        ts5 = "".join(["baaaabbb"] * (num_timestamp/8))
        ts6 = "".join(["bbaaaabb"] * (num_timestamp/8))
        df = pd.DataFrame()
        for i, ts in enumerate([ts1, ts2, ts3, ts4, ts5, ts6]):
            df[i] = list(ts)
        df.columns = ["CR2_0000", "CR2_0001", "CR2_0002", "CR2_0003", "CR2_0004", "CR2_0005"]
        df.index.name = COL_TS

    elif "complex" in filename:
        num_timestamp = (num_timestamp / 24) * 24
        _t_num_timestamp = num_timestamp / 3

        sts1 = "".join(["abc"] * (_t_num_timestamp/3))
        sts2 = "".join(["cba"] * (_t_num_timestamp/3))
        
        sts3 = "".join(["bcbcbaba"] * (_t_num_timestamp/8))
        sts4 = "".join(["aaaabbbb"] * (_t_num_timestamp/8))

        sts5 = "".join(["aabb"]) * (_t_num_timestamp/4)
        sts6 = "".join(["ab"]) * (_t_num_timestamp/2)

        ts1 = sts1 + sts3 + sts5
        ts2 = sts2 + sts4 + sts6

        ts3 = sts1 + sts5 + sts3
        ts4 = sts2 + sts6 + sts4

        ts5 = sts3 + sts5 + sts1
        ts6 = sts4 + sts6 + sts2

        ts7 = "".join(["aabb"]) * (num_timestamp/4)
        ts8 = "".join(["ab"]) * (num_timestamp/2)

        df = pd.DataFrame()
        for i, ts in enumerate([ts1, ts2, ts3, ts4, ts5, ts6, ts7, ts8]):
            df[i] = list(ts)
        df.columns = ["CR2_0000", "CR2_0001", "CR2_0002", "CR2_0003", "CR2_0004", "CR2_0005", "CR2_0006", "CR2_0007"]
        df.index.name = COL_TS

    elif "random" in filename:
        _tot = sum(card_cnt.values()) * 1.0
        cardinality_distribution = {}   # generate the cardinality distribution for the synthetic data
        for k in card_cnt:
            cardinality_distribution[int(k)] = int(round(card_cnt[k] / _tot * num_sensors))

        # create synthetic sensor discrete time series
        df = pd.DataFrame()
        sensor_cnt = 0
        for k in cardinality_distribution:
            for _ in xrange(cardinality_distribution[k]):  # keep the cardinality distribution as in LKM data
                df[sensor_cnt] = pd.Series(generate_time_series_for_one_sensor(k, num_timestamp))
                sensor_cnt += 1
        # print df.nunique().values  # check cardinality

        # shuffle columns
        columns = df.columns.values
        random.shuffle(columns)
        df = df[columns]

        # assign sensor names
        sensor_id_list = []
        for i in xrange(df.shape[1]):
            sensor_id = sensor_prefix + '{:04d}'.format(i)
            sensor_id_list.append(sensor_id)
        df.columns = sensor_id_list
        df.index.name = COL_TS

    else:
        print "Do not how to create synthetic data for " + filename
        exit()

    data_folder = "/".join(filename.split("/")[:-1])
    if not os.path.exists(data_folder):
        os.makedirs(data_folder)
    df.to_csv(filename)


def generate_time_series_for_one_sensor(num_variables, num_timestamp):
    return list(str_generator(num_timestamp, chars=string.ascii_lowercase[:num_variables]))

def str_generator(size=6, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))
