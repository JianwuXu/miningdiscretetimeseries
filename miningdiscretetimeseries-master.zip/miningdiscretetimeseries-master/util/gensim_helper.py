"""
http://adventuresinmachinelearning.com/gensim-word2vec-tutorial/
"""

import os
import heapq

# The required input to the gensim Word2Vec module is an iterator object,
# which sequentially supplies sentences
# from which gensim will train the embedding layer
# Below builds your customized iterator
# keeps feeding the files in the <dirname> folder
class MySentences(object):
    def __init__(self, dirname, filename_prefix):
        self.dirname = dirname
        self.filename_prefix = filename_prefix
    
    def __iter__(self):
        for fname in os.listdir(self.dirname):
            if self.filename_prefix not in fname:
                continue
            for line in open(os.path.join(self.dirname, fname)):
                yield line.split()


def mostSimilaryPairs(model, topk=10):
    vocab = model.wv.vocab
    words = vocab.keys()

    heap = []
    for i in xrange(len(words)):
        for j in xrange(i+1, len(words)):
            sim = model.wv.similarity(words[i], words[j])
            myHeapPush(heap, [sim, words[i], words[j]], capacity=topk)

    print "most " + str(topk) + " similar pairs:"
    while heap:
        val = heapq.heappop(heap)
        print val[1] + "~" + val[2] + ":", round(val[0], 6)


def myHeapPush(heap, val, capacity=10):
    size = len(heap)
    if size < capacity:
        heapq.heappush(heap, val)
    else:
        heapq.heappushpop(heap, val)
