import tensorflow as tf
# from tensorflow.contrib.tensorboard.plugins import projector

import gensim
from gensim.models import word2vec
import logging
from gensim_helper import MySentences

import multiprocessing

import pandas as pd
import numpy as np
import math, os
import datetime as dt
from collections import Counter
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE

from constants import *
import word2vec_helper, misc


"""
http://adventuresinmachinelearning.com/word2vec-tutorial-tensorflow/
"""



#### Build word2vec using gensim
def buildWord2VecEmbeddingWithGensim(input_folder, params, visual, flog=None, verbose=False, num_parallel=4):
    if verbose:
        logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)

    sentences_folder = os.path.join(input_folder, FOLDER_SENTENCES)
    embeddings_folder = os.path.join(input_folder, FOLDER_EMBEDDINGS)
    if not os.path.exists(embeddings_folder):
        os.makedirs(embeddings_folder)

    sensor_list = pd.read_csv(os.path.join(input_folder, kw_sensors), header=None).values.flatten()
    num_cores = multiprocessing.cpu_count()
    num_parts = min(num_parallel, num_cores)   # num of parallel jobs, up to num_cores
    pdata = []
    for sensor_id in sensor_list:
        pdata.append([sensor_id, params, sentences_folder, embeddings_folder, flog])

    p = multiprocessing.Pool(num_parts)
    p.map(gensimWord2VecWorker, pdata)


def gensimWord2VecWorker((sensor_id, params, sentences_folder, embeddings_folder, flog)):
    misc.log("Sensor: " + sensor_id, flog)

    # build word2vec for current sensor
    sentences = MySentences(sentences_folder, sensor_id)
    model = word2vec.Word2Vec(sentences, iter=params["iter"], min_count=params["min_count"], 
                            size=params["size"], workers=params["workers"], batch_words=params["batch_words"])
    model.save(os.path.join(embeddings_folder, sensor_id))
    misc.log("Sensor: " + sensor_id + " done", flog)


##############################
# Below: build word2vec using tensorflow
# not used, use gensim instead
##############################
def buildWord2VecEmbeddingWithTF(fp_input, params, visual):
    misc.makeDirectories(params["visualization_path"], rmPrev=True)

    df = pd.read_csv(fp_input)
    df.drop(COL_TS, axis=1, inplace=True)

    for sensor_id in df:
        buildEmbeddingForOneWordSequence(sensor_id, df[sensor_id], params, visual)
        exit()


def buildEmbeddingForOneWordSequence(sensor_id, sequence, params, visual, test=False, flog=None):
    batch_size = params["batch_size"]
    embedding_size = params["embedding_size"]

    word_counter = Counter(sequence)
    vocabulary_size = len(word_counter)  # build with full vocabulary
    misc.log(sensor_id + " vocab_size=" + str(vocabulary_size), flog)

    if test:
        # We pick a random validation set to sample nearest neighbors. Here we limit the
        # validation samples to the words that have a low numeric ID, which by
        # construction are also the most frequent.
        valid_size = 5     # Random set of words to evaluate similarity on.
        valid_window = min(10, vocabulary_size)  # Only pick dev samples in the head of the distribution (most frequent words).
        valid_examples = np.random.choice(valid_window, valid_size, replace=False)
        top_k = 8  # number of nearest neighbors to check

    #### prepare dictionary used by word2vec
    data, count, dictionary, reverse_dictionary = word2vec_helper.collect_data(sequence, vocabulary_size)

    #### build Skip-diagram graph
    graph = tf.Graph()
    with graph.as_default():
        # Input data.
        train_inputs = tf.placeholder(tf.int32, shape=[batch_size], name="train_inputs")
        train_context = tf.placeholder(tf.int32, shape=[batch_size, 1], name="train_context")
        if test:
            valid_dataset = tf.constant(valid_examples, dtype=tf.int32, name="valid_dataset")

        #### embedding/hidden layer: [vocabulary_size] --> [vocabulary_size*embedding_size]
        # Look up embeddings for inputs.
        embeddings = tf.Variable(tf.random_uniform([vocabulary_size, embedding_size], -1.0, 1.0), name="embeddings")
        embed = tf.nn.embedding_lookup(embeddings, train_inputs)

        #### output layer: [vocabulary_size*embedding_size] --> [vocabulary_size]

        """
        #### linear layer (matrix multiplication)
        # Construct the variables for the softmax
        weights = tf.Variable(tf.truncated_normal([embedding_size, vocabulary_size], stddev=1.0 / math.sqrt(embedding_size)))
        biases = tf.Variable(tf.zeros([vocabulary_size]))
        hidden_out = tf.transpose(tf.matmul(tf.transpose(weights), tf.transpose(embed))) + biases

        #### loss function
        # convert train_context to a one-hot format -- needed by cross_entropy
        train_one_hot = tf.one_hot(train_context, vocabulary_size)
        cross_entropy = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=hidden_out, labels=train_one_hot))
        tf.summary.scalar("cross_entropy", cross_entropy)

        #### Construct the SGD optimizer using a learning rate of 1.0.
        optimizer = tf.train.GradientDescentOptimizer(learning_rate).minimize(cross_entropy)
        #### #### optimizing softmax/cross_entropy is very expensive
        """

        # Construct the variables for the NCE loss
        # instead of optimizing softmax, it is better to optimize NCE loss (negative sampling)
        nce_weights = tf.Variable(
            tf.truncated_normal([vocabulary_size, embedding_size],
                                stddev=1.0 / math.sqrt(embedding_size)), name="NCE_weights")
        tf.summary.histogram("NCE_weights", nce_weights)

        nce_biases = tf.Variable(tf.zeros([vocabulary_size]), name="NCE_biases")
        tf.summary.histogram("NCE_biases", nce_biases)

        nce_loss = tf.reduce_mean(
            tf.nn.nce_loss(weights=nce_weights,
                           biases=nce_biases,
                           labels=train_context,
                           inputs=embed,
                           num_sampled=params["num_sampled"],
                           num_classes=vocabulary_size))
        tf.summary.scalar("nce_loss", nce_loss)

        optimizer = tf.train.GradientDescentOptimizer(params["learning_rate"]).minimize(nce_loss)

        # Compute the cosine similarity between mini-batch examples and all embeddings.
        norm = tf.sqrt(tf.reduce_sum(tf.square(embeddings), 1, keep_dims=True))  # L2 norm
        normalized_embeddings = embeddings / norm
        
        if test:
            ### This is not needed for optimizing skip-gram
            ### but to visually show the progress of training -- the quality of nearest neighbours keeps improving
            valid_embeddings = tf.nn.embedding_lookup(normalized_embeddings, valid_dataset)
            similarity = tf.matmul(valid_embeddings, normalized_embeddings, transpose_b=True)
            # similarity: [valid_size, embedding_size] * [vocabulary_size * embedding_size]' = [valid_size, vocabulary_size]
            # similarity[i][j] represents the cosine similarity between validation word i and word j in training data set

        # Add variable initializer.
        init = tf.global_variables_initializer()

    #### train word2vec
    nce_start_time = dt.datetime.now()
    with tf.Session(graph=graph) as session:
        merged = tf.summary.merge_all()
        writer = tf.summary.FileWriter(params["visualization_path"], session.graph)
        
        # We must initialize all variables before we use them.
        init.run()
        # print('Initialized')

        average_loss = 0
        for step in xrange(params["num_steps"]):
            batch_inputs, batch_context = word2vec_helper.generate_batch(data, batch_size, params["num_skips"], params["skip_window"])
            feed_dict = {train_inputs: batch_inputs, train_context: batch_context}

            # We perform one update step by evaluating the optimizer op (including it
            # in the list of returned values for session.run()
            _, loss_val = session.run([optimizer, nce_loss], feed_dict=feed_dict)
            average_loss += loss_val

            result = session.run(merged, feed_dict=feed_dict)
            writer.add_summary(result, step)

            if step % params["print_every"] == 0:
                if step > 0:
                    average_loss /= params["print_every"]
                # The average loss is an estimate of the loss over the last <print_every> batches.
                misc.log("Average loss at step " + str(step) + " = " + str(average_loss), flog, 1)
                average_loss = 0

        # periodically save your model variables
        saver = tf.train.Saver()
        saver.save(session, os.path.join(params["visualization_path"], "model.ckpt"), step)

        # add embedding to at the last step
        final_embeddings = normalized_embeddings.eval()

        if test:
            # # Note that this is expensive (~20% slowdown if computed every 500 steps)
            sim = similarity.eval()  # equals to session.run(similarity)
            for i in xrange(valid_size):
                valid_word = reverse_dictionary[valid_examples[i]]
                nearest = (-sim[i, :]).argsort()[1:top_k + 1]
                log_str = 'Nearest to %s:' % valid_word
                for k in xrange(top_k):
                    close_word = reverse_dictionary[nearest[k]]
                    log_str = '%s %s,' % (log_str, close_word)
                print("~~~" + log_str)

    nce_end_time = dt.datetime.now()
    # misc.log("NCE method took {} minutes ".format((nce_end_time-nce_start_time).total_seconds()) + " to run " + str(num_steps) + " steps", flog)

    print "final_embeddings:", final_embeddings.shape
    if visual["visualization_dimension"] > 0:
        for visualizing_with in [vi_pca, vi_tsne]:
            fig_name = os.path.join(params["visualization_path"], visualizing_with + ".pdf")
            visulizeEmbeddings(fig_name, final_embeddings, visualizing_with, visual["visualization_dimension"])


def visulizeEmbeddings(fig_name, final_embeddings, visualizing_with, dim, fontsize=14):
    if visualizing_with == vi_pca:
        vi = PCA(n_components=dim)
    elif visualizing_with == vi_tsne:
        vi = TSNE(n_components=dim)

    x = vi.fit_transform(final_embeddings)
    fig = plt.figure()
    plt.title(visualizing_with.upper(), fontsize=fontsize)
    if dim == 2:
        ax = fig.add_subplot(111)
        ax.scatter(x[:, 0], x[:, 1])
    elif dim == 3:
        ax = fig.add_subplot(111, projection='3d')
        ax.scatter(x[:, 0], x[:, 1], x[:, 2])
    plt.savefig(fig_name, bbox_inches='tight')
    # plt.show()
    plt.close()
