import gensim, os
from gensim_helper import *
import numpy as np

fp_model = os.path.join("..", "data", "synthetic_data_small", "embeddings", "CR2_0000")
model = gensim.models.Word2Vec.load(fp_model)

# get vocabulary (dict)
# print model.wv.vocab

# get the word vector of "aabaababba"
print "aabaababba:", model.wv["aabaababba"]

# get the most common words
print "most common words:"
print model.wv.index2word[:5]

# get the least common words
print "least common words:"
print model.wv.index2word[-5:]


# mostSimilaryPairs(model)

##### how to use gensim word2vec in Tensorflow
# convert the wv word vectors into a numpy matrix that is suitable for insertion
# into Tensorflow/Keras models
vocab_size = len(model.wv.vocab)
embedding_dim = len(model.wv[model.wv.index2word[0]])
embedding_matrix = np.zeros((vocab_size, embedding_dim))
for i in xrange(vocab_size):
    embedding_vector = model.wv[model.wv.index2word[i]]
    if embedding_vector is not None:
        embedding_matrix[i] = embedding_vector

import tensorflow as tf
valid_size = 3
valid_examples = np.random.choice(100, valid_size, replace=False)  # random pick 10 from the most 100 frequent words
print valid_examples
valid_dataset = tf.constant(valid_examples, dtype=tf.int32)

saved_embeddings = tf.constant(embedding_matrix)
# trainable=False --> do not update embedding layer
embedding = tf.Variable(initial_value=saved_embeddings, trainable=False)

# create the cosine similarity operations
norm = tf.sqrt(tf.reduce_sum(tf.square(embedding), 1, keep_dims=True))
normalized_embeddings = embedding / norm

# look up embeddings in embedding layer
valid_embeddings = tf.nn.embedding_lookup(normalized_embeddings, valid_dataset)
similarity = tf.matmul(valid_embeddings, normalized_embeddings, transpose_b=True)

init = tf.global_variables_initializer()
with tf.Session() as sess:
    sess.run(init)

    sim = similarity.eval()
    for i in xrange(valid_size):
        valid_word = model.wv.index2word[valid_examples[i]]
        topk = 3
        nearest = (-sim[i, :]).argsort()[1: topk+1]
        print "nearest to " + valid_word + ":",
        for k in xrange(topk):
            print model.wv.index2word[nearest[k]],
        print



