import os, shutil

def log(line, flog=None, indent=0, enter=True):
    newline = "".join(["\t"] * indent) + line
    print newline
    if flog:
        if enter:
            flog.write(newline + "\n")
        else:
            flog.write(newline)
        

def makeDirectories(dirname, rmPrev=False):
    if rmPrev:
        if os.path.exists(dirname):
            shutil.rmtree(dirname)
        os.makedirs(dirname)
    else:
        if not os.path.exists(dirname):
            os.makedirs(dirname)


def checkExistence(path):
    if not os.path.exists(path):
        print "Cannot find " + path
        return False
    else:
        return True