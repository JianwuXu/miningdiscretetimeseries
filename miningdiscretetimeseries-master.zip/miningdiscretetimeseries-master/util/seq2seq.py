"""
https://www.tensorflow.org/tutorials/seq2seq
@article{luong17,
  author  = {Minh{-}Thang Luong and Eugene Brevdo and Rui Zhao},
  title   = {Neural Machine Translation (seq2seq) Tutorial},
  journal = {https://github.com/tensorflow/nmt},
  year    = {2017},
}
"""
import os, subprocess
from constants import *
import misc
from nltk.translate.bleu_score import sentence_bleu, corpus_bleu
from nmt.utils import evaluation_utils



def testForSensorPairs(model_folder, input_file, output_file, nmt_data_folder, inference_list=None, verbose=True, flog=None):
    if inference_list is None:
        cmd_test = buildTestingCommand(model_folder, input_file, output_file)
    else:
        cmd_test = buildTestingCommandWithInferenceList(model_folder, input_file, output_file, nmt_data_folder, inference_list)

    if verbose:
        misc.log(cmd_test, flog)

    p = subprocess.Popen(cmd_test, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate()


def evaluateForSensorPairs(ref_file, trans_file, metric, subword_option=None):
    score = evaluation_utils.evaluate(ref_file, trans_file, metric, subword_option)
    return score


def buildTestingCommandWithInferenceList(model_folder, input_file, output_file, nmt_data_folder, inference_list=None):
    if inference_list is None:
        return buildTestingCommand(model_folder, input_file, output_file)
    
    output_folder = "/".join(output_file.split("/")[:-1])
    output_filename = output_file.split("/")[-1]
    output_folder = os.path.join(output_folder, FOLDER_ATTENTION_IMAGES)
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    src, tgt = model_folder.split("/")[-1].split("#")

    cmd = "python -m nmt.nmt "
    cmd += "--out_dir=" + str(model_folder) + " "
    cmd += "--inference_input_file=" + str(input_file) + " "
    cmd += "--inference_output_file=" + str(os.path.join(output_folder, output_filename)) + " "

    # cmd += "--infer_batch_size=1 "  # must specify in the training
    cmd += "--inference_list=" + str(",".join([str(x) for x in inference_list])) + " "

    cmd += "--src=" + str(src) + " --tgt=" + str(tgt) + " "
    cmd += "--vocab_prefix=" + os.path.join(nmt_data_folder, kw_vocab) + "  "

    return cmd


def buildTestingCommand(model_folder, input_file, output_file):
    cmd = "python -m nmt.nmt "
    cmd += "--out_dir=" + str(model_folder) + " "
    cmd += "--inference_input_file=" + str(input_file) + " "
    cmd += "--inference_output_file=" + str(output_file) + " "

    return cmd


def trainForSensorPairs(sensor1, sensor2, data_folder, model_folder, params, verbose=True, flog=None):
    cmd_train = buildTrainingCommand(sensor1, sensor2, data_folder, model_folder,
                num_train_steps=params["num_train_steps"],
                steps_per_stats=params["steps_per_stats"],
                num_layers=params["num_layers"],
                num_units=params["num_units"],
                dropout=params["dropout"],
                metrics=params["metrics"])
    if verbose:
        misc.log(cmd_train, flog)

    p = subprocess.Popen(cmd_train, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate()
    
    for out in [FN_STDOUT, FN_STDERR]:
        fout = open(os.path.join(model_folder, out), "w")
        if out == FN_STDOUT:
            fout.write(stdout)
        elif out == FN_STDERR:
            fout.write(stderr)
        fout.close



def buildTrainingCommand(source, target, data_folder, model_folder, 
                        num_train_steps=10, steps_per_stats=5, num_layers=2, num_units=128,
                        dropout=0.2, metrics=kw_bleu):
    cmd = "python -m nmt.nmt "
    cmd += "--attention=scaled_luong "
    cmd += "--src=" + str(source) + " --tgt=" + str(target) + " "
    cmd += "--vocab_prefix=" + os.path.join(data_folder, kw_vocab) + "  "
    cmd += "--train_prefix=" + os.path.join(data_folder, kw_train) + "  "
    cmd += "--dev_prefix=" + os.path.join(data_folder, kw_dev) + "  "
    cmd += "--test_prefix=" + os.path.join(data_folder, kw_test) + "  "
    cmd += "--out_dir=" + model_folder + " "
    cmd += "--num_train_steps=" + str(num_train_steps) + " "
    cmd += "--steps_per_stats=" + str(steps_per_stats) + " "
    cmd += "--num_layers=" + str(num_layers) + " "
    cmd += "--num_units=" + str(num_units) + " "
    cmd += "--dropout=" + str(dropout) + " "
    cmd += "--metrics=" + str(metrics) + " "

    # This must specify in the training command, 
    # in order to support "inference_list" in infering (to save attention images for them)
    # by default, it is set to be 32
    cmd += "--infer_batch_size=1 "  
    
    return cmd


def generateVisualizationCommand(model_folder, port=22222):
    cmd = "tensorboard --port " + str(port) + " --logdir " + model_folder
    return cmd


def generateVimDiffCommand(kw, source, target, nmt_data_folder, nmt_model_folder):
    cmd = "vimdiff " + os.path.join(nmt_data_folder, kw + "." + target) + " "
    cmd += os.path.join(nmt_model_folder, source + kw_scat + target, "output_" + kw)
    return cmd