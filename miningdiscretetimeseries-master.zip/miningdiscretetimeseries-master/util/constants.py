RANDOM_SEED = 123

kw_scat = "#"  # used to concat two sensor ids

# commonly used column names
COL_TS = "timestamp"

# folder names
FOLDER_PARAMS = "parameters"
FOLDER_SENTENCES = "sentences"
FOLDER_EMBEDDINGS = "embeddings"
FOLDER_DATA = "data"
FOLDER_FIGS = "figs"
FOLDER_SUMMARY = "summary"
# intermediate folders begin with "_"
FOLDER_NMT_DATA = "_nmt_data"
FOLDER_NMT_MODEL = "_nmt_model"
FOLDER_NMT_INFER = "_nmt_infer"
FOLDER_ATTENTION_IMAGES = "attention_images"

FN_STDOUT = "stdout.log"
FN_STDERR = "stderr.log"

# keywords
kw_sensors = "sensors"
kw_train = "train"
kw_dev = "dev"
kw_test = "test"
kw_infer = "infer"
kw_vocab = "vocab"

kw_bleu = "bleu"
kw_bleu_smooth = "bleu_smooth"
kw_accuracy = "accuracy"
kw_word_accuracy = "word_accuracy"

kw_normal, kw_abnormal = "normal", "abnormal"
kw_gt = "GT"


vi_pca, vi_tsne = "pca", "t-sne"