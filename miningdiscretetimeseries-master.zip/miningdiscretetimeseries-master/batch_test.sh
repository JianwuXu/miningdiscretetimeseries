# python s3_test.py params_synthetic_data_random.json
# sleep 30

# python s3_test.py params_synthetic_data_simple.json
# sleep 30

python s3_test.py params_synthetic_data_simple_slen10_wstep1.json
sleep 30

python s3_test.py params_synthetic_data_simple_slen20_wstep20.json
sleep 30

python s3_test.py params_synthetic_data_simple_char.json
# sleep 30

# python s3_test.py params_synthetic_data_complex.json
# sleep 30
