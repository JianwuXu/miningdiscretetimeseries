# tensorboard --port 22222 --logdir visualization/word2vec/
# tensorboard --port 22222 --logdir _nmt_model/synthetic_data_simple/CR2_0000#CR2_0001
tensorboard --port 22222 --logdir _nmt_model/synthetic_data_simple_with_delay/CR2_0000#CR2_0000


vimdiff _nmt_data/synthetic_data_simple_with_delay/dev.CR2_0000 _nmt_model/synthetic_data_simple_with_delay/CR2_0000#CR2_0000/output_dev