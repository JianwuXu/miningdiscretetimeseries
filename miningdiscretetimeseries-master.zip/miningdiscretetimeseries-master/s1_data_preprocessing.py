import os
import pandas as pd
from util import preprocessing, buildingWordEmbedding, seq2seq, misc
from util.constants import *
import json
from pprint import pprint
import matplotlib.pyplot as plt
import heapq
from collections import defaultdict, Counter


flog = None


def main():
    #### load parameters
    # param_filename = "params_synthetic_data_random.json"
    # param_filename = "params_synthetic_data_simple.json"
    # param_filename = "params_synthetic_data_simple_slen10_wstep1.json"
    # param_filename = "params_synthetic_data_simple_slen20_wstep20.json"
    # param_filename = "params_synthetic_data_simple_char.json"
    param_filename = "params_synthetic_data_complex.json"

    fp_params = os.path.join(FOLDER_PARAMS, param_filename)
    with open(fp_params) as f:
        params = json.load(f)
    # pprint(params)

    if params["using_synthetic_data"] == 0:
        data_filename = params["data_filename"]
    elif params["using_synthetic_data"] == 1:
        data_filename = param_filename.split(".")[0].replace("params_", "") + ".csv"

    data_filename = os.path.join(FOLDER_DATA, data_filename)
    data_folder = os.path.join(FOLDER_DATA, data_filename.split("/")[-1].replace(".csv", ""))
    nmt_data_folder = os.path.join(FOLDER_NMT_DATA, data_filename.split("/")[-1].replace(".csv", ""))
    nmt_model_folder = os.path.join(FOLDER_NMT_MODEL, data_filename.split("/")[-1].replace(".csv", ""))
    
    #### read csv files, for each sensor's time series
    #### (1) build vocabulary and sentences
    #### (2) build word2vec (optional, as seq2seq can also train embedding from scratch)
    #### (3) split into train/dev/test for later seq2seq model
    preprocessing_data(data_filename, params, data_folder, nmt_data_folder, build_word2vec=False)


def preprocessing_data(data_filename, params, data_folder, nmt_data_folder, build_word2vec=True):
    df = preprocessing.getTimeSeries(data_filename, num_sensors=params["num_sensors"], num_timestamp=params["num_timestamps"],
                                    using_synthetic_data=params["using_synthetic_data"], LKM=params["LKM"])

    #### step1: for every time series, chop it into words with fixed length (i.e., 5 chars -- 5 minutes per word)
    misc.log("***Creating word vocabulary for " + data_filename, flog)
    fp_words = preprocessing.splitCharsIntoWords(df, params["data_preparation"], data_folder)
    misc.log("output_file: " + fp_words, flog, 1)

    sentences_folder = preprocessing.splitWordsIntoSentences(fp_words, params["data_preparation"], data_folder)
    misc.log("sentences_folder: " + sentences_folder, flog, 1)

    #### step2: build word2vec for each word sequence
    #### seq2seq can build word2vec from scrach or used the pretrained word2vec embedding
    if build_word2vec:
        misc.log("***Train Word2Vec for each time series", flog)
        with open(os.path.join("parameters", "word2vec.json")) as f:
            word2vec_params = json.load(f)
        buildingWordEmbedding.buildWord2VecEmbeddingWithGensim(input_folder=data_folder, params=word2vec_params["gensim"], visual=word2vec_params["visualization"])

    #### step3: split dataset into train/dev/test
    preprocessing.split_dataset(data_folder, nmt_data_folder, params["data_preparation"])


if __name__ == "__main__":
    main()
